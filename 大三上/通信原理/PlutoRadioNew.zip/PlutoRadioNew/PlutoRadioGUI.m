function PlutoRadioGUI
% ======================================================================
% PlutoSDR 可视化无线电系统 GUI（固定西安经典电台列表版）
%
% 功能：
%   A) 广播接收：只显示 8 个“西安经典电台”，可一键播放/停止
%   B) 本地音频 FM 自发自收：可设置中心频率，播放 Handel，停止
%   C) 右侧显示最近一帧接收频谱
%
% 特点：
%   - 取消扫描/误检：列表固定，符合教学演示
%   - 广播播放与自发自收互斥，避免 "radio already owned"
%   - 修复 load handel.mat 在嵌套函数(static workspace)报错：结构体加载
% ======================================================================

    try, delete(timerfindall); catch, end

    % ---------------- 共享状态 ----------------
    S = struct();
    S.isPlayingRadio  = false;
    S.isRunningLocal  = false;
    S.lastRxData      = [];
    S.lastFs          = 200e3;
    S.selectedStation = 1;

    % 固定：西安经典电台频点列表（你给出的）
    S.xiAnRadioStations = [
        struct('frequency', 89.6e6, 'name', '陕西新闻广播');
        struct('frequency', 98.8e6, 'name', '陕西音乐广播');
        struct('frequency', 91.6e6, 'name', '陕西交通广播');
        struct('frequency', 101.8e6, 'name', '陕西都市广播');
        struct('frequency', 95.0e6, 'name', '西安新闻广播');
        struct('frequency', 93.1e6, 'name', '西安音乐广播');
        struct('frequency', 104.3e6, 'name', '西安交通广播');
        struct('frequency', 90.4e6, 'name', '陕西农村广播');
    ];

    releasePluto();

    % ---------------- GUI ----------------
    hFig = figure('Name','PlutoSDR FM 通信系统（西安经典电台）', ...
        'Position',[220 80 1280 720], ...
        'NumberTitle','off', ...
        'MenuBar','none', ...
        'Color',[0.96 0.97 0.98]);

    guidata(hFig,S);

    % 顶部标题条
    uipanel('Parent',hFig,'Units','pixels','Position',[0 680 1280 40], ...
        'BackgroundColor',[0.12 0.20 0.35],'BorderType','none');
    uicontrol(hFig,'Style','text','String','PlutoSDR FM Mini Communication System', ...
        'Position',[16 686 900 28],'FontSize',18,'FontWeight','bold', ...
        'ForegroundColor','w','BackgroundColor',[0.12 0.20 0.35], ...
        'HorizontalAlignment','left');
    uicontrol(hFig,'Style','text','String','Xi’an Classic Stations + Local FM Tx/Rx', ...
        'Position',[900 688 360 22],'FontSize',11, ...
        'ForegroundColor',[0.85 0.9 1],'BackgroundColor',[0.12 0.20 0.35], ...
        'HorizontalAlignment','right');

    leftW = 380;
    pad = 14;

    % -------- Panel A：广播播放（固定列表） --------
    pA = uipanel('Parent',hFig,'Title','A. 收听广播（西安经典电台）', ...
        'FontSize',13,'FontWeight','bold', ...
        'Units','pixels','Position',[pad 280 leftW 390], ...
        'BackgroundColor',[0.98 0.98 0.99]);

    uicontrol(pA,'Style','text','String','电台列表（固定）：', ...
        'Position',[16 332 346 20], ...
        'BackgroundColor',get(pA,'BackgroundColor'), ...
        'HorizontalAlignment','left','FontSize',11,'FontWeight','bold');

    % 列表内容：名称 + 频率
    listStr = makeStationListStr(S.xiAnRadioStations);
    hListStations = uicontrol(pA,'Style','listbox', ...
        'Position',[16 140 346 190], ...
        'FontSize',11,'String',listStr,'Value',1, ...
        'Callback',@onSelectStation);

    % 播放/停止（紧凑）
    uicontrol(pA,'Style','pushbutton','String','播放选中电台', ...
        'Position',[16 92 168 36],'FontSize',11,'FontWeight','bold', ...
        'BackgroundColor',[0.20 0.65 0.35],'ForegroundColor','w', ...
        'Callback',@onPlayStation);

    uicontrol(pA,'Style','pushbutton','String','停止播放', ...
        'Position',[194 92 168 36],'FontSize',11,'FontWeight','bold', ...
        'BackgroundColor',[0.85 0.30 0.30],'ForegroundColor','w', ...
        'Callback',@onStopPlay);

    % 可选：快速“刷新功率”（只测这 8 个频点，不做误检）
    uicontrol(pA,'Style','pushbutton','String','测量各电台功率（可选）', ...
        'Position',[16 44 346 36],'FontSize',11,'FontWeight','bold', ...
        'BackgroundColor',[0.18 0.52 0.80],'ForegroundColor','w', ...
        'Callback',@onMeasurePowers);

    % -------- Panel B：本地自发自收 --------
    pB = uipanel('Parent',hFig,'Title','B. 本地音频 FM 自发自收（单机回环演示）', ...
        'FontSize',13,'FontWeight','bold', ...
        'Units','pixels','Position',[pad 40 leftW 220], ...
        'BackgroundColor',[0.98 0.98 0.99]);

    uicontrol(pB,'Style','text','String','中心频率 (MHz)：', ...
        'Position',[16 150 120 22],'BackgroundColor',get(pB,'BackgroundColor'), ...
        'HorizontalAlignment','left','FontSize',11);
    hEditFc = uicontrol(pB,'Style','edit','String','915', ...
        'Position',[140 148 90 28],'FontSize',11,'BackgroundColor','w');

    uicontrol(pB,'Style','text','String','TX 增益 (dB)：', ...
        'Position',[16 118 120 22],'BackgroundColor',get(pB,'BackgroundColor'), ...
        'HorizontalAlignment','left','FontSize',11);
    hEditTxGain = uicontrol(pB,'Style','edit','String','-15', ...
        'Position',[140 116 90 28],'FontSize',11,'BackgroundColor','w');

    uicontrol(pB,'Style','text','String','RX AGC：', ...
        'Position',[16 86 120 22],'BackgroundColor',get(pB,'BackgroundColor'), ...
        'HorizontalAlignment','left','FontSize',11);
    hPopupRxAgc = uicontrol(pB,'Style','popupmenu', ...
        'String',{'AGC Slow Attack','AGC Fast Attack','Manual'}, ...
        'Value',1, ...
        'Position',[140 84 180 28],'FontSize',11,'BackgroundColor','w');

    uicontrol(pB,'Style','pushbutton','String','开始自发自收（Handel）', ...
        'Position',[16 40 170 36],'FontSize',11,'FontWeight','bold', ...
        'BackgroundColor',[0.18 0.52 0.80],'ForegroundColor','w', ...
        'Callback',@onStartLocalFM);

    uicontrol(pB,'Style','pushbutton','String','停止自发自收', ...
        'Position',[192 40 170 36],'FontSize',11,'FontWeight','bold', ...
        'BackgroundColor',[0.85 0.30 0.30],'ForegroundColor','w', ...
        'Callback',@onStopLocalFM);

    % -------- 右侧：状态栏 + 频谱 --------
    pStatus = uipanel('Parent',hFig,'Units','pixels', ...
        'Position',[leftW + 2*pad, 640, 1280-leftW-3*pad, 30], ...
        'BackgroundColor',[1 1 1],'BorderType','line');
    hStatus = uicontrol(pStatus,'Style','text','String','状态：空闲', ...
        'Position',[8 3 900 22], 'FontSize',11, ...
        'BackgroundColor','w','HorizontalAlignment','left');

    pSpec = uipanel('Parent',hFig,'Title','最近一帧接收信号频谱（绝对幅度）', ...
        'FontSize',12,'FontWeight','bold', ...
        'Units','pixels','Position',[leftW + 2*pad, 40, 1280-leftW-3*pad, 590], ...
        'BackgroundColor',[1 1 1]);

    hAx = axes('Parent',pSpec,'Position',[0.08 0.14 0.88 0.78]);
    xlabel(hAx,'Frequency Offset (MHz)');
    ylabel(hAx,'Magnitude (dB)');
    title(hAx,'Spectrum');
    grid(hAx,'on');

    hFig.CloseRequestFcn = @onCloseGUI;

    % ================== Callback ==================

    function setStatus(msg)
        if ishandle(hStatus), set(hStatus,'String',msg); end
    end

    function stopAllAndRelease()
        S = guidata(hFig);
        S.isPlayingRadio = false;
        S.isRunningLocal = false;
        guidata(hFig,S);
        pause(0.15);
        releasePluto();
    end

    function onSelectStation(~,~)
        S = guidata(hFig);
        S.selectedStation = get(hListStations,'Value');
        guidata(hFig,S);
    end

    % --- 可选：测量 8 个频点功率（不筛选、不误检） ---
    function onMeasurePowers(~,~)
        S = guidata(hFig);
        if S.isPlayingRadio || S.isRunningLocal
            setStatus('状态：请先停止当前播放/自发自收');
            return;
        end

        setStatus('状态：正在测量 8 个经典电台功率...');
        drawnow;

        stopAllAndRelease();

        Fs = 200e3; Nfrm = 4096;
        try
            rx = sdrrx('Pluto','RadioID','usb:0', ...
                'BasebandSampleRate',Fs, ...
                'SamplesPerFrame',Nfrm, ...
                'OutputDataType','double', ...
                'GainSource','Manual','Gain',40);
        catch ME
            setStatus(['状态：创建 RX 失败 - ' ME.message]);
            return;
        end

        newStr = cell(numel(S.xiAnRadioStations),1);
        for k = 1:numel(S.xiAnRadioStations)
            rx.CenterFrequency = S.xiAnRadioStations(k).frequency;
            pause(0.05);
            x = rx(); x = x - mean(x);
            p_db = 10*log10(mean(abs(x).^2) + eps);
            newStr{k} = sprintf('%s  |  %.1f MHz  |  P=%.1f dB', ...
                S.xiAnRadioStations(k).name, ...
                S.xiAnRadioStations(k).frequency/1e6, ...
                p_db);

            plotSpectrumAbs(hAx, x, Fs);
            drawnow;
        end
        release(rx);

        set(hListStations,'String',newStr);
        setStatus('状态：功率测量完成（仅经典电台）');
    end

    % --- 播放选中电台 ---
    function onPlayStation(~,~)
        S = guidata(hFig);

        if S.isRunningLocal
            setStatus('状态：请先停止自发自收');
            return;
        end

        idx = get(hListStations,'Value');
        idx = max(1, min(idx, numel(S.xiAnRadioStations)));
        Fc = S.xiAnRadioStations(idx).frequency;
        name = S.xiAnRadioStations(idx).name;

        stopAllAndRelease();
        S = guidata(hFig);
        S.isPlayingRadio = true;
        guidata(hFig,S);

        setStatus(sprintf('状态：正在播放 %s (%.1f MHz) ...', name, Fc/1e6));
        drawnow;

        FsBB    = 240e3;        % 你已验证可用
        audioFs = 48e3;

        try
            rx = sdrrx('Pluto','RadioID','usb:0', ...
                'CenterFrequency',Fc, ...
                'BasebandSampleRate',FsBB, ...
                'SamplesPerFrame',8192, ...
                'OutputDataType','double', ...
                'GainSource','AGC Fast Attack');
        catch ME
            setStatus(['状态：创建 RX 失败 - ' ME.message]);
            S.isPlayingRadio = false;
            guidata(hFig,S);
            return;
        end

        try
            player = audioDeviceWriter('SampleRate',audioFs);
        catch ME
            setStatus(['状态：创建音频输出失败 - ' ME.message]);
            release(rx);
            S.isPlayingRadio = false;
            guidata(hFig,S);
            return;
        end

        fmdemod_raw = @(r) [0; angle(r(2:end).*conj(r(1:end-1)))];

        while true
            S = guidata(hFig);
            if ~S.isPlayingRadio || ~ishandle(hFig)
                break;
            end

            [r,valid,~] = rx();
            if ~valid || isempty(r)
                drawnow;
                continue;
            end

            r = r - mean(r);
            plotSpectrumAbs(hAx, r, FsBB);

            audio_bb = fmdemod_raw(r);
            audio_bb = audio_bb - mean(audio_bb);

            audio_out = resample(audio_bb, audioFs, FsBB);
            m = max(abs(audio_out));
            if m > 1e-3
                audio_out = audio_out / m * 0.9;
            end
            player(audio_out);

            drawnow;
        end

        release(rx);
        release(player);

        S = guidata(hFig);
        S.isPlayingRadio = false;
        guidata(hFig,S);
        setStatus('状态：播放结束');
    end

    function onStopPlay(~,~)
        S = guidata(hFig);
        S.isPlayingRadio = false;
        guidata(hFig,S);
        setStatus('状态：停止播放请求已发出');
    end

    % --- 本地自发自收 ---
    function onStartLocalFM(~,~)
        S = guidata(hFig);

        if S.isPlayingRadio
            setStatus('状态：请先停止广播播放');
            return;
        end

        FcMHz = str2double(get(hEditFc,'String'));
        if isnan(FcMHz) || FcMHz <= 0
            setStatus('状态：中心频率输入错误');
            return;
        end
        Fc = FcMHz * 1e6;

        txGain = str2double(get(hEditTxGain,'String'));
        if isnan(txGain)
            setStatus('状态：TX 增益输入错误');
            return;
        end

        agcChoice = get(hPopupRxAgc,'Value');
        agcStrs   = get(hPopupRxAgc,'String');
        rxGainMode = agcStrs{agcChoice};

        stopAllAndRelease();
        S = guidata(hFig);
        S.isRunningLocal = true;
        guidata(hFig,S);

        setStatus(sprintf('状态：本地 FM 自发自收 @ %.1f MHz ...', FcMHz));
        drawnow;

        % ---- 修复：在嵌套函数里用结构体方式 load ----
        Snd = load('handel.mat');   % {y, Fs}
        x_in  = Snd.y;
        Fs_in = Snd.Fs;

        if size(x_in,2) > 1
            x_in = mean(x_in,2);
        end

        FsAudio = 16000;
        x = resample(x_in, FsAudio, Fs_in);
        x = x / (max(abs(x))+eps);

        FsBB = 200e3;
        kf   = 2*pi*75e3;

        x_bb = resample(x, FsBB, FsAudio);
        x_bb = x_bb - mean(x_bb);

        phi   = cumsum(x_bb)/FsBB * kf;
        tx_bb = exp(1j*phi);
        tx_bb = tx_bb / (max(abs(tx_bb))+eps) * 0.7;

        try
            tx = sdrtx('Pluto','RadioID','usb:0', ...
                'CenterFrequency',Fc, ...
                'BasebandSampleRate',FsBB, ...
                'Gain',txGain, ...
                'ChannelMapping',1);
        catch ME
            setStatus(['状态：创建 TX 失败 - ' ME.message]);
            S.isRunningLocal = false;
            guidata(hFig,S);
            return;
        end

        try
            if strcmpi(rxGainMode,'Manual')
                rx = sdrrx('Pluto','RadioID','usb:0', ...
                    'CenterFrequency',Fc, ...
                    'BasebandSampleRate',FsBB, ...
                    'SamplesPerFrame',4096, ...
                    'OutputDataType','double', ...
                    'GainSource','Manual','Gain',40);
            else
                rx = sdrrx('Pluto','RadioID','usb:0', ...
                    'CenterFrequency',Fc, ...
                    'BasebandSampleRate',FsBB, ...
                    'SamplesPerFrame',4096, ...
                    'OutputDataType','double', ...
                    'GainSource',rxGainMode);
            end
        catch ME
            setStatus(['状态：创建 RX 失败 - ' ME.message]);
            release(tx);
            S.isRunningLocal = false;
            guidata(hFig,S);
            return;
        end

        try
            player = audioDeviceWriter('SampleRate',FsAudio);
        catch ME
            setStatus(['状态：创建音频输出失败 - ' ME.message]);
            release(tx); release(rx);
            S.isRunningLocal = false;
            guidata(hFig,S);
            return;
        end

        fmdemod_raw = @(r) [0; angle(r(2:end).*conj(r(1:end-1)))];

        frameLen = 4096;
        N = numel(tx_bb);
        idx = 1;

        while true
            S = guidata(hFig);
            if ~S.isRunningLocal || ~ishandle(hFig)
                break;
            end

            % TX
            if idx + frameLen - 1 <= N
                tx_frame = tx_bb(idx:idx+frameLen-1);
                idx = idx + frameLen;
            else
                idx = 1;
                tx_frame = tx_bb(idx:idx+frameLen-1);
                idx = idx + frameLen;
            end
            tx(tx_frame);

            % RX
            [r,valid,~] = rx();
            if ~valid || isempty(r)
                drawnow;
                continue;
            end

            r = r - mean(r);
            plotSpectrumAbs(hAx, r, FsBB);

            audio_bb = fmdemod_raw(r);
            audio_bb = audio_bb - mean(audio_bb);

            audio_out = resample(audio_bb, FsAudio, FsBB);
            m = max(abs(audio_out));
            if m > 1e-3
                audio_out = audio_out / m * 0.9;
            end
            player(audio_out);

            drawnow;
        end

        release(tx);
        release(rx);
        release(player);

        S = guidata(hFig);
        S.isRunningLocal = false;
        guidata(hFig,S);
        setStatus('状态：自发自收结束');
    end

    function onStopLocalFM(~,~)
        S = guidata(hFig);
        S.isRunningLocal = false;
        guidata(hFig,S);
        setStatus('状态：停止自发自收请求已发出');
    end

    function onCloseGUI(src,~)
        S = guidata(src);
        S.isPlayingRadio = false;
        S.isRunningLocal = false;
        guidata(src,S);
        pause(0.2);
        releasePluto();
        delete(src);
    end
end

% ================== 工具函数 ==================

function listStr = makeStationListStr(stations)
    listStr = cell(numel(stations),1);
    for k = 1:numel(stations)
        listStr{k} = sprintf('%s  |  %.1f MHz', stations(k).name, stations(k).frequency/1e6);
    end
end

function releasePluto()
    try, tx = sdrtx('Pluto','RadioID','usb:0'); release(tx); catch, end
    try, rx = sdrrx('Pluto','RadioID','usb:0'); release(rx); catch, end
end

function plotSpectrumAbs(hAx, x, Fs)
    if isempty(x) || Fs <= 0, return; end
    N = numel(x);
    if N < 32, return; end
    X = fftshift(fft(x));
    P = 20*log10(abs(X) + eps);
    f = linspace(-Fs/2, Fs/2, N)/1e6;
    plot(hAx, f, P, 'LineWidth',1.0);
    ylim(hAx, [min(P(:))-5, max(P(:))+5]);
    xlabel(hAx,'Frequency Offset (MHz)');
    ylabel(hAx,'Magnitude (dB)');
    title(hAx,'Spectrum');
    grid(hAx,'on');
    drawnow limitrate;
end
