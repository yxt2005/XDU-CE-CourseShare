function [TP, FP, FN] = evaluate_detection(true_events, detected_events, tol)
% =============================================================
% 文件名：evaluate_detection.m
% 功能：事件检测性能评价：TP/FN/FP
% 输入：
%   true_events     - 真实事件时间（秒）
%   detected_events - 检测事件时间（秒）
%   tol             - 容许误差（秒），如 0.05
% =============================================================

if nargin < 3
    tol = 0.1;  % 默认 50 ms
end

TP = 0;  % 正确检测
FP = 0;  % 误检
FN = 0;  % 漏检

detected_used = zeros(size(detected_events));

for i = 1:length(true_events)
    t0 = true_events(i);
    % 找到最近的检测时间
    diff = abs(detected_events - t0);
    [minval, idx] = min(diff);

    if minval <= tol
        TP = TP + 1;
        detected_used(idx) = 1;
    else
        FN = FN + 1;
    end
end

% 未使用的检测事件就是误检
FP = sum(detected_used == 0);

end
