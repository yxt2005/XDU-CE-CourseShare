function plot_detection_result(t, x, true_events, ...
                               feature, t_feature, detected_events, title_str)
% =============================================================
% 绘制检测结果：时域信号 + 特征曲线 + 检测点
% =============================================================

subplot(1,2,1);
plot(t, x, 'k'); hold on;
for p = true_events, xline(p,'r--'); end
title('时域信号（含真实事件）');
xlabel('Time (s)');

subplot(1,2,2);
plot(t_feature, feature, 'b', 'LineWidth',1.2); hold on;
stem(detected_events, ones(size(detected_events))*max(feature)*0.9, ...
     'r','LineWidth',1.2);
title(title_str);
xlabel('Time (s)');
ylabel('Feature Value');

end
