function event_times = detect_events(feature, time_axis, threshold, min_dist)
% =============================================================
% 文件名：detect_events.m
% 功能：根据特征曲线进行事件检测
%
% 输入参数：
%   feature   - 特征序列（如 E、B、SC）
%   time_axis - 特征对应的时间轴（单位秒）
%   threshold - 阈值
%   min_dist  - 两次事件最小间隔（秒）
%
% 输出：
%   event_times - 检测到的事件时间列表（秒）
%
% 原理：
%   1) 先找出大于阈值的点
%   2) 使用 findpeaks 找峰值（避免连续多次触发）
% =============================================================

if nargin < 4
    min_dist = 0.05;  % 默认最小间隔 50ms
end

% 1. 初步选择超过阈值的部分
mask = feature > threshold;

% 2. 对“超过阈值”的点做峰值检测
[~, locs] = findpeaks(feature .* mask, ...
                      'MinPeakDistance', min_dist / (time_axis(2) - time_axis(1)));

% 3. 转换为时间
event_times = time_axis(locs);

end
