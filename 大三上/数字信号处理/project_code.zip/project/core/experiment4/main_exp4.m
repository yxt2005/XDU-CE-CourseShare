clear; clc; close all;

% =============================================================
% 实验 4：事件检测算法 + 参数影响分析
% =============================================================

%% 1. 生成信号（机械冲击信号）
[x, fs, true_events] = generate_signals('mech');
t = (0:length(x)-1)/fs;

%% 2. 设置参数
win_len = 512;
overlap = 256;
nfft = 512;

[X, f, t_stft] = compute_stft_custom(x, fs, 'hamming', win_len, overlap, nfft);

%% ---------------- 特征计算 ----------------
[E, t_e]      = feature_energy(x, fs, win_len, overlap);
[B, t_b]      = feature_bandenergy(X, f, t_stft, [0 300]);
[SC, t_sc]    = feature_centroid(X, f, t_stft);

%% ---------------- 事件检测 ----------------
th_E = 0.7;
th_B = 0.7;
th_SC = 0.35;

det_E  = detect_events(E, t_e,  th_E, 0.05);
det_B  = detect_events(B, t_b,  th_B, 0.05);
det_SC = detect_events(abs([0 diff(SC)]), t_sc, th_SC, 0.05);

%% ---------------- 性能评价 ----------------
fprintf("===== 事件检测性能评价 =====\n");

[TP_E, FP_E, FN_E] = evaluate_detection(true_events, det_E);
[TP_B, FP_B, FN_B] = evaluate_detection(true_events, det_B);
[TP_SC, FP_SC, FN_SC] = evaluate_detection(true_events, det_SC);

fprintf("短时能量法（Short-Time Energy）：\n");
fprintf("  正确检测 TP = %d\n", TP_E);
fprintf("  误检     FP = %d\n", FP_E);
fprintf("  漏检     FN = %d\n\n", FN_E);

fprintf("频带能量法（Band Energy）：\n");
fprintf("  正确检测 TP = %d\n", TP_B);
fprintf("  误检     FP = %d\n", FP_B);
fprintf("  漏检     FN = %d\n\n", FN_B);

fprintf("谱质心变化法（Spectral Centroid）：\n");
fprintf("  正确检测 TP = %d\n", TP_SC);
fprintf("  误检     FP = %d\n", FP_SC);
fprintf("  漏检     FN = %d\n\n", FN_SC);


%% ---------------- 绘图展示 ----------------
figure('Name','实验4 - 事件检测（短时能量）');
plot_detection_result(t, x, true_events, E, t_e, det_E, '短时能量');

figure('Name','实验4 - 事件检测（频带能量）');
plot_detection_result(t, x, true_events, B, t_b, det_B, '频带能量');

figure('Name','实验4 - 事件检测（谱质心变化）');
plot_detection_result(t, x, true_events, abs([0 diff(SC)]), t_sc, det_SC, '谱质心变化');
