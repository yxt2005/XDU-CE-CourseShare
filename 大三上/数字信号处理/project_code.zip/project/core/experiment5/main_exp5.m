clear; clc; close all;

% =============================================================
% 实验 5：多场景事件检测对比（机械 / 音乐 / 车辆）
% =============================================================

scenes = {'mech', 'music', 'car'};
scene_names = {'机械冲击', '音乐鼓点', '车辆经过（多普勒）'};

win_len = 512;
overlap = 256;
nfft = 512;

results = [];   % 用于最后汇总性能对比表

for s = 1:length(scenes)
    
    scene = scenes{s};
    fprintf("\n===== 场景：%s =====\n", scene_names{s});
    
    % 1. 生成信号
    [x, fs, true_events] = generate_signals(scene);
    t = (0:length(x)-1)/fs;

    % 2. STFT
    [X, f, t_stft] = compute_stft_custom(x, fs, 'hamming', win_len, overlap, nfft);

    % 3. 特征
    [E, t_e]   = feature_energy(x, fs, win_len, overlap);
    [B, t_b]   = feature_bandenergy(X, f, t_stft, [0 300]);
    [SC, t_sc] = feature_centroid(X, f, t_stft);

    dSC = abs([0 diff(SC)]);

    % 4. 自动阈值（基于均值）
    th_E  = mean(E)  + 0.5*std(E);
    th_B  = mean(B)  + 0.8*std(B);
    th_SC = mean(dSC)+ 1.0*std(dSC);

    % 5. 检测
    det_E  = detect_events(E,  t_e,  th_E,  0.05);
    det_B  = detect_events(B,  t_b,  th_B,  0.05);
    det_SC = detect_events(dSC,t_sc, th_SC, 0.05);

    % 6. 性能评价
    [TP_E, FP_E, FN_E] = evaluate_detection(true_events, det_E);
    [TP_B, FP_B, FN_B] = evaluate_detection(true_events, det_B);
    [TP_SC, FP_SC, FN_SC] = evaluate_detection(true_events, det_SC);

    % 保存结果用于最终表格
    results = [results; TP_E FP_E FN_E TP_B FP_B FN_B TP_SC FP_SC FN_SC];

    % 7. 绘图展示
    figure('Name',['实验5 - ' scene_names{s}],'NumberTitle','off');

    subplot(3,2,1);
    plot(t, x, 'k'); hold on;
    for p = true_events, xline(p, 'r--'); end
    title(['场景：' scene_names{s} '（时域含真实事件）']);
    xlabel('Time (s)');

    subplot(3,2,3);
    plot(t_e, E, 'b'); hold on;
    plot(det_E, ones(size(det_E))*max(E)*0.9,'ro');
    title('短时能量检测');

    subplot(3,2,4);
    plot(t_b, B, 'b'); hold on;
    plot(det_B, ones(size(det_B))*max(B)*0.9,'ro');
    title('频带能量检测');

    subplot(3,2,5);
    plot(t_sc, dSC, 'b'); hold on;
    plot(det_SC, ones(size(det_SC))*max(dSC)*0.9,'ro');
    title('谱质心变化检测');
end

%% 最终性能表格输出
fprintf("\n\n===== 多场景检测性能对比表 =====\n");
fprintf("场景\t\tSTE(TP FP FN)\tBand(TP FP FN)\tSC(TP FP FN)\n");

for i = 1:3
    fprintf("%s\t%d %d %d\t\t%d %d %d\t\t%d %d %d\n", ...
        scene_names{i}, results(i,1:3), results(i,4:6), results(i,7:9));
end
