function [X, f, t] = compute_stft_custom(x, fs, win_type, win_len, overlap, nfft)
% =============================================================
% 文件名：compute_stft_custom.m
% 功能： 计算信号的 STFT，便于统一处理和绘图
% 输入：
%   x        - 信号
%   fs       - 采样率
%   win_type - 'rect' / 'hamming' / 'hann' / 'blackman'
%   win_len  - 窗长（如 256, 512, 1024）
%   overlap  - 重叠样本数
%   nfft     - FFT 点数
% 输出：
%   X        - 复数 STFT 结果
%   f        - 频率轴
%   t        - 时间轴
% =============================================================

% 1. 窗函数选择
switch lower(win_type)
    case 'rect'
        win = rectwin(win_len);
    case 'hamming'
        win = hamming(win_len);
    case 'hann'
        win = hann(win_len);
    case 'blackman'
        win = blackman(win_len);
    otherwise
        error('未知窗函数类型');
end

% 2. 调用 MATLAB 内置 spectrogram
[X, f, t] = spectrogram(x, win, overlap, nfft, fs);

end
