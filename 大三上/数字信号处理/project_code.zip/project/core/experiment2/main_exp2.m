clear; clc; close all;

% =============================================================
% 实验 2：STFT 时频分析与窗参数影响
% 本实验分两部分：
%   Part 1：不同窗函数比较
%   Part 2：不同窗长比较
% =============================================================

%% ================== 1. 生成信号（机械冲击） ==================
[x, fs, events] = generate_signals('mech');


%% ================== Part 1：窗函数对比 ==================
win_len = 512;         % 固定窗长
overlap = 256;         % 固定重叠
nfft = 1024;           % 固定 FFT 点数
win_types = {'rect', 'hamming', 'hann', 'blackman'};

figure('Name','不同窗函数对比','NumberTitle','off');

for i = 1:length(win_types)
    [X, f, t] = compute_stft_custom(x, fs, win_types{i}, ...
                                    win_len, overlap, nfft);
    
    subplot(2, 2, i);
    plot_stft(X, f, t, fs, ['Window = ' upper(win_types{i})]);
end

sgtitle('实验2 - 不同窗函数对短时频谱的影响','FontSize',14,'FontWeight','bold');


%% ================== Part 2：窗长对比 ==================
win_lens = [128, 256, 512, 1024];
win_type = 'hamming';     % 固定窗函数

figure('Name','不同窗长对比','NumberTitle','off');

for i = 1:length(win_lens)
    win_len = win_lens(i);
    overlap = floor(win_len/2);
    nfft = win_len;
    
    [X, f, t] = compute_stft_custom(x, fs, win_type, ...
                                    win_len, overlap, nfft);
    
    subplot(2, 2, i);
    plot_stft(X, f, t, fs, ['Window Length = ' num2str(win_len)]);
end

sgtitle('实验2 - 不同窗长对时间/频率分辨率的影响','FontSize',14,'FontWeight','bold');
