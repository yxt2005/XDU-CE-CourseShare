function plot_stft(X, f, t, fs, title_str)
% =============================================================
% 文件名：plot_stft.m
% 功能： 绘制时频图（幅度谱）
% 输入：
%   X        - STFT 复数矩阵
%   f        - 频率轴
%   t        - 时间轴
%   fs       - 采样率
%   title_str- 图标题
% =============================================================

imagesc(t, f, 20*log10(abs(X)));   % 转为 dB 展示
axis xy;                            % 与通常时频坐标一致
colormap jet;                       % 彩色好看
colorbar;
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title(title_str);

end
