% =============================================================
% 文件名：main_exp1.m
% 功能： 实验一主程序
%       生成三类非平稳信号并绘制时域波形（含真实事件）
% =============================================================

clear; clc; close all;

% 实验 1 要测试的三种场景
scenes = {'mech', 'music', 'car'};

for i = 1:length(scenes)
    
    % 1. 生成信号
    [x, fs, true_events] = generate_signals(scenes{i});
    
    % 2. 绘图
    figure('Name', scenes{i}, 'NumberTitle', 'off');
    plot_time_domain(x, fs, true_events);
    
    % 3. 设置标题
    switch scenes{i}
        case 'mech'
            sgtitle('实验1 - 机械振动冲击信号（时域）');
        case 'music'
            sgtitle('实验1 - 音乐鼓点信号（时域）');
        case 'car'
            sgtitle('实验1 - 车辆多普勒信号（时域）');
    end
end
