% =============================================================
% 文件名：plot_time_domain.m
% 功能： 绘制时域波形，并标注真实事件（竖线/星号）
% 输入：
%   x           - 信号
%   fs          - 采样率
%   true_events - 事件时间点（秒）
% =============================================================


function plot_time_domain(x, fs, true_events, scene_name)
% =============================================================
% 绘制时域信号，并以红色竖线和红点标注真实事件
% 输入：
%   x           - 信号
%   fs          - 采样率
%   true_events - 事件时间点（秒）
%   scene_name  - 标题（如 '机械振动冲击信号'）
% =============================================================

t = (0:length(x)-1)/fs;   % 时间轴

plot(t, x, 'k', 'LineWidth', 1); hold on;
xlabel('Time (s)');
ylabel('Amplitude');

% ---- 加强图形可读性 ----
grid on;
set(gca, 'FontSize', 12);

% ---- 标注事件 ----
for p = true_events
    
    % 竖线标注事件
    xline(p, 'r--', 'LineWidth', 1.2);
    
    % 在信号曲线上找到对应的点位置
    [~, idx] = min(abs(t - p));
    
    % 在信号上标红点
    plot(t(idx), x(idx), 'ro', 'MarkerSize', 8, 'LineWidth', 1.5);
end

% ---- 图例 ----
if ~isempty(true_events)
    legend('Signal', 'Event', 'Location','best');
end

% ---- 标题统一由外部 sgtitle 控制 ----
if nargin == 4
    title(scene_name);
end

end
