clear; clc; close all;

% =============================================================
% 实验三：特征提取（短时能量 / 频带能量 / 谱质心）
% =============================================================

%% 1. 生成信号（机械冲击）
[x, fs, events] = generate_signals('mech');
t = (0:length(x)-1)/fs;

%% 2. 参数设置
win_len = 512;
overlap = 256;
nfft = 512;

%% 3. 计算 STFT
[X, f, t_stft] = compute_stft_custom(x, fs, 'hamming', win_len, overlap, nfft);

% 将 STFT 帧映射到秒
t_frames = t_stft;  % spectrogram 已经给出时间轴（秒）


%% ============= 特征 1：短时能量 =============
[E, t_e]  = feature_energy(x, fs, win_len, overlap);


%% ============= 特征 2：频带能量 =============
band = [0 300];   % 机械冲击主要在低频
[B, t_b]      = feature_bandenergy(X, f, t_stft, [0 300]);


%% ============= 特征 3：谱质心 =============
[SC, t_sc]    = feature_centroid(X, f, t_stft);

%% ============= 绘图 =============
figure('Name','实验3 - 特征提取','NumberTitle','off');

% ---- 子图1：时域波形 ----
subplot(2,2,1);
plot(t, x, 'k'); hold on;
for p = events, xline(p,'r--'); end
title('时域信号');
xlabel('Time (s)');

% ---- 子图2：短时能量 ----
subplot(2,2,2);
plot(t_e, E, 'LineWidth', 1.2); hold on;
title('短时能量（STE）');
xlabel('Time (s)');
ylabel('Norm Energy');

% ---- 子图3：频带能量 ----
subplot(2,2,3);
plot(t_frames, B, 'LineWidth', 1.2); hold on;
title('频带能量（Band Energy [0–300 Hz]）');
xlabel('Time (s)');
ylabel('Norm Energy');

% ---- 子图4：谱质心 ----
subplot(2,2,4);
plot(t_frames, SC, 'LineWidth', 1.2); hold on;
title('谱质心（Spectral Centroid）');
xlabel('Time (s)');
ylabel('Norm Value');

sgtitle('实验3 - 非平稳信号的三种特征提取','FontSize',14,'FontWeight','bold');
