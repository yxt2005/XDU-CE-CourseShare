function [SC, t_c] = feature_centroid(X, f, t_frames)
% =============================================================
% 计算谱质心，并返回与 STFT 对应的时间轴（秒）
% =============================================================

mag = abs(X);          % |X(k,n)|
num = f(:).' * mag;    % Σ f_k * |X|
den = sum(mag, 1);     % Σ |X|

SC = num ./ (den + eps);
if max(SC) > 0
    SC = SC / max(SC); % 归一化方便比较
end

t_c = t_frames(:).';   % 时间轴（秒）

end
