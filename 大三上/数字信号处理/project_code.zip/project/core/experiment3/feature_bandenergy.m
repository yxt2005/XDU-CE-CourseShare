function [B, t_b] = feature_bandenergy(X, f, t_frames, band)
% =============================================================
% 计算指定频带的能量，并返回与 STFT 对应的时间轴（秒）
% 输入：
%   X        - STFT 复数矩阵
%   f        - 频率轴
%   t_frames - STFT 的时间轴（spectrogram 给出的，单位：秒）
%   band     - [f_low f_high] 指定频段
% 输出：
%   B    - 频带能量（已归一化）
%   t_b  - 时间轴（秒），与 B 一一对应
% =============================================================

f_low  = band(1);
f_high = band(2);

idx = find(f >= f_low & f <= f_high);

B = sum(abs(X(idx,:)).^2, 1);
if max(B) > 0
    B = B / max(B);
end

t_b = t_frames(:).';   % 保证是行向量，单位秒

end
