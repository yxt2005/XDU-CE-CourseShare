function [E, t_e] = feature_energy(x, fs, win_len, overlap)
% =============================================================
% 文件名：feature_energy.m（buffer 版本，稳定可靠）
% 功能：计算短时能量 Short-Time Energy (STE)
% 原理：
%   1）使用 buffer 对信号进行分帧
%   2）对每一帧加窗并计算能量
%   3）给出每一帧中心对应的时间轴
% 说明：
%   - 避免手写索引，自动处理“最后一帧长度不够”等问题
%   - 不会出现“左侧和右侧元素数目不同”的错误
% =============================================================

% 确保列向量
x = x(:);

% 每帧移动步长
step = win_len - overlap;

% 1. 用 buffer 分帧（Signal Processing Toolbox 函数）
%    frames 大小为 [win_len, numFrames]
frames = buffer(x, win_len, overlap, 'nodelay');

% 2. 加窗（Hamming 窗）
win = hamming(win_len);
win_mat = repmat(win, 1, size(frames, 2));  % 与 frames 同尺寸
frames_win = frames .* win_mat;

% 3. 计算每一帧能量
E = sum(frames_win.^2, 1);   % 1 × numFrames

% 4. 归一化
if max(E) > 0
    E = E / max(E);
end

% 5. 帧中心时间轴
numFrames = size(frames, 2);
frame_centers = ((0:numFrames-1)*step + (win_len-1)/2);  % 以样本为单位
t_e = frame_centers / fs;    % 转为秒

end
