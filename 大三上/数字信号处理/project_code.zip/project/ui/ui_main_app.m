function ui_main_app

addpath(genpath('..\'));
% =============================================================
% 文件名：ui_main_app.m
% 功能： 非平稳信号事件检测与可视化平台 (UI 版)
% 说明：
%   - 通过下拉框选择场景（机械 / 音乐 / 车辆）
%   - 调节 STFT 参数和检测阈值
%   - 显示时域、时频图、特征曲线、检测结果
% 运行方式：
%   在 MATLAB 命令行输入： ui_main_app
% =============================================================

    % ---------- 创建主窗口 ----------
    fig = uifigure('Name','非平稳信号事件检测系统',...
               'Position',[100 80 1300 700]);

    % ===== 主题配色（科研蓝 + 浅灰） =====
    mainBlue   = [0.10 0.35 0.80];   % 主色
    lightGray  = [0.96 0.96 0.96];   % 浅灰背景
    panelGray  = [0.98 0.98 0.98];   % 面板背景
    fig.Color  = lightGray;          % 整体背景色

    lblTitle = uilabel(fig,'Text','突发 / 标志事件检测系统平台',...
               'FontSize',20,'FontWeight','bold',...
               'HorizontalAlignment','center',...
               'FontColor',mainBlue,...
               'Position',[0 660 1300 30]);   % 居中


    % ========== 1. 创建 4 个坐标轴区域 ==========
    leftW = 900;
    leftH = 620;
    
    % 第一行两个图
    axTime = uiaxes(fig,'Position',[20 360 430 280]);   % 左上
    axTime.BackgroundColor = panelGray;
    axTime.GridColor = [0.8 0.8 0.8];
    axTime.XGrid = 'on'; axTime.YGrid = 'on';
    axTime.FontSize = 11;
    title(axTime,'时域信号','FontSize',14,'FontWeight','bold','Color',mainBlue);
    
    axSTFT = uiaxes(fig,'Position',[470 360 430 280]);  % 右上
    axSTFT.BackgroundColor = panelGray;
    axSTFT.GridColor = [0.8 0.8 0.8];
    axSTFT.FontSize = 11;
    title(axSTFT,'STFT 时频图','FontSize',14,'FontWeight','bold','Color',mainBlue);
    
    % 第二行两个图
    axFeat = uiaxes(fig,'Position',[20 50 430 280]);    % 左下
    axFeat.BackgroundColor = panelGray;
    axFeat.GridColor = [0.8 0.8 0.8];
    axFeat.XGrid = 'on'; axFeat.YGrid = 'on';
    axFeat.FontSize = 11;
    title(axFeat,'特征曲线','FontSize',14,'FontWeight','bold','Color',mainBlue);
    
    axDet = uiaxes(fig,'Position',[470 50 430 280]);    % 右下
    axDet.BackgroundColor = panelGray;
    axDet.GridColor = [0.8 0.8 0.8];
    axDet.XGrid = 'on'; axDet.YGrid = 'on';
    axDet.FontSize = 11;
    title(axDet,'特征 + 事件检测','FontSize',14,'FontWeight','bold','Color',mainBlue);



    % ========== 2. 控制面板 ==========
    ctrl = uipanel(fig,'Title','参数设置',...
           'FontSize',16,'FontWeight','bold',...
           'TitlePosition','centertop',...
           'ForegroundColor',mainBlue,...
           'BackgroundColor',panelGray,...
           'Position',[940 40 340 620]);



    % ----- 信号场景选择 -----
    uilabel(ctrl,'Text','信号场景：','Position',[20 550 100 22],...
    'FontSize',13,'FontWeight','bold','FontColor',mainBlue);

    ddScene = uidropdown(ctrl,...
        'Items',{'机械冲击','音乐鼓点','车辆多普勒'},...
        'ItemsData',{'mech','music','car'},...
        'Position',[130 550 180 22],...
        'Value','mech'); % 默认值


    % ----- 特征选择 -----
    uilabel(ctrl,'Text','特征选择：','Position',[20 500 100 22],...
    'FontSize',13,'FontWeight','bold','FontColor',mainBlue);

    ddFeat = uidropdown(ctrl,...
        'Items',{'短时能量','频带能量','谱质心变化'},...
        'ItemsData',{'STE','BAND','DSC'},...
        'Position',[130 500 180 22],...
        'Value','STE');  % 默认值



    % --- 窗长 ---
    uilabel(ctrl,'Text','窗长：', ...
        'Position',[20 440 60 22], ...
        'FontSize',13,'FontWeight','bold','FontColor',mainBlue);
    
    lblWin = uilabel(ctrl,'Text','512', ...
        'Position',[80 440 40 22], ...
        'FontSize',13,'FontWeight','bold');
    
    sWin = uislider(ctrl,...
        'Position',[130 450 180 3], ... % slider 右移
        'Limits',[128 1024],...
        'MajorTicks',[128 256 512 768 1024],...
        'Value',512);


    
    % --- 重叠率 ---
    uilabel(ctrl,'Text','重叠率：', ...
        'Position',[20 380 60 22], ...
        'FontSize',13,'FontWeight','bold','FontColor',mainBlue);
    
    lblOv = uilabel(ctrl,'Text','0.50', ...
        'Position',[80 380 40 22], ...
        'FontSize',13,'FontWeight','bold');
    
    sOv = uislider(ctrl,...
        'Position',[130 390 180 3], ...
        'Limits',[0.1 0.9],...
        'MajorTicks',[0.1 0.25 0.5 0.75 0.9],...
        'Value',0.5);

    % --- 阈值 ---
    uilabel(ctrl,'Text','阈值：', ...
        'Position',[20 320 60 22], ...
        'FontSize',13,'FontWeight','bold','FontColor',mainBlue);
    
    lblTh = uilabel(ctrl,'Text','0.30', ...
        'Position',[80 320 40 22], ...
        'FontSize',13,'FontWeight','bold');
    
    sTh = uislider(ctrl,...
        'Position',[130 330 180 3], ...
        'Limits',[0 1],...
        'MajorTicks',[0 0.2 0.4 0.6 0.8 1],...
        'Value',0.3);



    sWin.ValueChangingFcn = @(src,event) set(lblWin,'Text', sprintf('%d', round(event.Value/2)*2));
    sOv.ValueChangingFcn  = @(src,event) set(lblOv, 'Text', sprintf('%.2f', event.Value));
    sTh.ValueChangingFcn  = @(src,event) set(lblTh, 'Text', sprintf('%.2f', event.Value));

    % ===== 检测结果统计区域 =====
    statsPanel = uipanel(ctrl, ...
        'Title','检测结果统计', ...
        'FontSize',14, 'FontWeight','bold', ...
        'ForegroundColor',mainBlue, ...
        'BackgroundColor',panelGray, ...
        'Position',[20 150 300 100]);   % 按钮上方位置（推荐）
    
    
    % 真实事件（深蓝）
    lblTrue = uilabel(statsPanel, ...
        'Text','真实事件数：0', ...
        'Position',[10 55 200 20], ...
        'FontSize',12, ...
        'FontColor',mainBlue);   % 主色
    
    
    % TP 正确检测（绿色）
    lblTP = uilabel(statsPanel, ...
        'Text','正确检测 TP：0', ...
        'Position',[10 30 200 20], ...
        'FontSize',12, ...
        'FontColor',[0.10 0.60 0.10]);   % 绿色
    
    
    % FN 漏检（橙色）
    lblFN = uilabel(statsPanel, ...
        'Text','漏检 FN：0', ...
        'Position',[150 55 200 20], ...
        'FontSize',12, ...
        'FontColor',[0.90 0.50 0.10]);   % 橙色
    
    
    % FP 误检（红色）
    lblFP = uilabel(statsPanel, ...
        'Text','误检 FP：0', ...
        'Position',[150 30 200 20], ...
        'FontSize',12, ...
        'FontColor',[0.85 0.10 0.10]);   % 红色



    % ----- 按钮：生成并分析 / 重置 -----
    % ----- 按钮布局：放在控制条下面，右侧一排 -----
    btnReset = uibutton(ctrl,'Text','恢复默认',...
                    'Position',[40 100 120 35],...
                    'FontWeight','bold',...
                    'BackgroundColor',[0.9 0.9 0.9],...
                    'FontColor',[0.2 0.2 0.2],...
                    'ButtonPushedFcn',@onReset);

    btnRun = uibutton(ctrl,'Text','生成并分析',...
                  'Position',[180 100 120 35],...
                  'FontWeight','bold',...
                  'BackgroundColor',mainBlue,...
                  'FontColor','white',...
                  'ButtonPushedFcn',@onRun);

    % ========== 3. 内部状态变量（用 struct 存） ==========
    data.x = [];
    data.fs = 8000;
    data.true_events = [];
    data.X = [];
    data.f = [];
    data.t_stft = [];
    guidata(fig,data);   % 把数据存进图窗

    % 初始运行一次
    onRun();

    % =========================================================
    % 回调函数：运行分析
    % =========================================================
    function onRun(~,~)
        % 取控件值
        data = guidata(fig);
        scene = ddScene.Value;
        featMode = ddFeat.Value;
        win_len = round(sWin.Value/2)*2;  % 保证为偶数
        overlapRatio = sOv.Value;
        overlap = round(win_len * overlapRatio);
        nfft = max(512, 2^nextpow2(win_len));

        % 1) 生成信号
        [x, fs, true_events] = generate_signals(scene);
        data.x = x;
        data.fs = fs;
        data.true_events = true_events;

        t = (0:length(x)-1)/fs;

        % 2) STFT
        [X, f, t_stft] = compute_stft_custom(x, fs, 'hamming', win_len, overlap, nfft);
        data.X = X; data.f = f; data.t_stft = t_stft;

        % 3) 特征提取
        [E, t_e]   = feature_energy(x, fs, win_len, overlap);
        [B, t_b]   = feature_bandenergy(X, f, t_stft, [0 300]);
        [SC, t_sc] = feature_centroid(X, f, t_stft);
        dSC = abs([0 diff(SC)]);

        % 4) 阈值
        th = sTh.Value;
        switch featMode
            case 'STE'
                feature = E;       t_feat = t_e;   featName = '短时能量';
            case 'BAND'
                feature = B;       t_feat = t_b;   featName = '频带能量';
            case 'DSC'
                feature = dSC;     t_feat = t_sc;  featName = '谱质心变化';
        end

        % 可以做一个“自适应”建议：如果滑条值为 0，就自动设阈值
        if th == 0
            th = mean(feature) + 0.5*std(feature);
        end

        % 5) 事件检测
        det_times = detect_events(feature, t_feat, th, 0.05);

        % 6) 绘图 ---------------

        % 时域 + 真实事件
        cla(axTime);
        plot(axTime, t, x,'k'); hold(axTime,'on');
        for p = true_events
            xline(axTime,p,'r--');
        end
        title(axTime, sprintf('场景：%s（时域含真实事件）',sceneLabel(scene)));

        % STFT 图
        cla(axSTFT);
        imagesc(axSTFT, t_stft, f, 20*log10(abs(X)+eps));
        axis(axSTFT,'xy');
        colormap(axSTFT,'turbo');
        title(axSTFT,'STFT 时频图');
        xlabel(axSTFT,'Time (s)'); ylabel(axSTFT,'Frequency (Hz)');

        % 特征曲线
        cla(axFeat);
        plot(axFeat, t_feat, feature,'b','LineWidth',1.2); hold(axFeat,'on');
        yline(axFeat, th,'r--','LineWidth',1);
        title(axFeat, sprintf('%s（阈值=%.2f）', featName, th),...
              'Color',mainBlue);
        xlabel(axFeat,'Time (s)');

        % 特征 + 事件检测
        cla(axDet);
        plot(axDet, t_feat, feature,'b','LineWidth',1.2); hold(axDet,'on');
        if ~isempty(det_times)
            stem(axDet, det_times, ...
                ones(size(det_times))*max(feature)*0.9,...
                'r','filled');
        end
        title(axDet, sprintf('%s + 事件检测', featName),...
              'Color',mainBlue);
        xlabel(axDet,'Time (s)');
        
        % =============================
        % Step 8: 统计检测性能 TP/FP/FN
        % =============================
        tol = 0.05;  % 容差，与 detect_events 一致
    
        trueCount = length(true_events);
        detCount  = length(det_times);
    
        TP = 0;
        matched = zeros(1, trueCount);
    
        % ---- 检查每个检测是否匹配真实事件 ----
        for i = 1:detCount
            for j = 1:trueCount
                if abs(det_times(i) - true_events(j)) <= tol
                    matched(j) = 1;
                end
            end
        end
    
        TP = sum(matched);
        FN = trueCount - TP;
        FP = detCount - TP;
    
        % ---- 更新 UI 显示 ----
        lblTrue.Text = sprintf('真实事件数：%d', trueCount);
        lblTP.Text   = sprintf('正确检测 TP：%d', TP);
        lblFN.Text   = sprintf('漏检 FN：%d', FN);
        lblFP.Text   = sprintf('误检 FP：%d', FP);

        guidata(fig,data);
    end

    % =========================================================
    % 回调函数：恢复默认参数
    % =========================================================
    function onReset(~,~)
        ddScene.Value = 'mech';
        ddFeat.Value  = 'STE';
        sWin.Value    = 512;
        sOv.Value     = 0.5;
        sTh.Value     = 0.3;
        onRun();
    end

    % 场景名字转中文
    function label = sceneLabel(code)
        switch code
            case 'mech',  label = '机械冲击';
            case 'music', label = '音乐鼓点';
            case 'car',   label = '车辆多普勒';
            otherwise,    label = code;
        end
    end

end
